# NOKI Design System

`@agrismartchain/noki-design-system` is the shared UI foundation for NOKI dashboard applications:

- `noki-admin`
- `noki-seller-portal`
- `noki-operations`
- `noki-contact-center`
- `noki-finance`

It ships generic, reusable primitives, layout/navigation/overlay components, a data-visualization
subsystem (built on Recharts), and reference dashboard patterns. It stays independent from NOKI
business logic, backend DTOs, generated contracts, and Next.js — no API calls, no hardcoded
business labels or workflows.

## Status

The official distribution channel is private npm packages on GitHub Packages:
`https://npm.pkg.github.com`. The package remains private through GitHub repository/package
permissions, not through `package.json#private`; that field is intentionally absent so the manual
publish workflow can publish to GitHub Packages.

Publishing is manual only through the `Publish Package` GitHub Actions workflow
(`workflow_dispatch`). It uses the repository `GITHUB_TOKEN`, publishes only to GitHub Packages,
does not use a permanent PAT, and does not create a Git tag or GitHub Release automatically.

Do not copy-paste these components into a dashboard app. This design system is the single source
of truth for shared UI; dashboards consume it as a dependency, not as a template.

## Requirements

- Node.js `>=24.0.0 <25`
- pnpm `10.23.0`

## Commands

```bash
pnpm install
pnpm lint
pnpm typecheck
pnpm test
pnpm build
pnpm verify:ssr
pnpm package:verify
pnpm consumer:verify    # packs the real tarball, installs it in an isolated external project
pnpm storybook          # local dev server
pnpm build:storybook
pnpm visual:test        # compare against committed screenshots
pnpm visual:update      # regenerate screenshots after an intentional change
pnpm check              # full gate: tokens, lint, typecheck, test, build, ssr, package, storybook, visual
```

`consumer:verify` is intentionally not part of `pnpm check` — it hits the network to install a
throwaway project's dependencies and is the slowest gate. It is required in CI and in the Release
Readiness workflow, and is safe to run locally any time.

## Installation From GitHub Packages

Consuming repositories must install exact versions from GitHub Packages and must have explicit
read access to the private package. Configure the scope in the consuming repo or user npm
configuration:

```ini
@agrismartchain:registry=https://npm.pkg.github.com
```

Developers need GitHub Packages authentication with `read:packages` in their secure user-level
npm configuration. Never commit tokens, `_authToken`, usernames, emails, or credentials to this
repository or to consuming applications.

Install a specific SemVer version:

```bash
pnpm add @agrismartchain/noki-design-system@0.2.0
```

## Usage

Once available to a dashboard as a dependency, applications import the public API and CSS
explicitly, then render under the dashboard theme contract:

```tsx
import { Button, Card, ThemeToggle } from "@agrismartchain/noki-design-system";
import "@agrismartchain/noki-design-system/styles.css";
```

```tsx
<div data-noki-theme="dashboard-light" data-density="comfortable" dir="ltr">
  {/* dashboard app */}
</div>
```

Use `data-noki-theme="dashboard-dark"` for dark mode and `dir="rtl"` / `lang="ar"` for Arabic
interfaces. The design system never reads or writes this attribute itself and never touches
`localStorage` — the consuming application owns theme persistence and where the attribute lives
in the DOM (typically the app root).

### Theme toggle

`ThemeToggle` is a small, unopinionated light/dark control. It works controlled or uncontrolled
and only calls `onThemeChange` — wiring that value to `data-noki-theme` (and to persistence, if
any) is the application's responsibility:

```tsx
import { ThemeToggle } from "@agrismartchain/noki-design-system";

<ThemeToggle theme={theme} onThemeChange={setTheme} />;
```

### Data visualization

Chart components (`LineChart`, `AreaChart`, `BarChart`, `DonutChart`, `Sparkline`, `ProgressRing`,
`MetricCard`, `ChartContainer`, `ChartTooltip`, `ChartLegend`) are a NOKI-styled layer over
Recharts. Recharts itself is never re-exported — only the design-system components are public API.

## Package Boundaries

Use only the public package exports:

- `@agrismartchain/noki-design-system`
- `@agrismartchain/noki-design-system/styles.css`

Deep imports into `dist/`, `src/`, component folders, stories, tests, or visual fixtures are not
supported. Consuming apps must never copy `src/` or component code; they must depend on the
private package and import the public API.

## No business logic

No NOKI business labels, DTOs, enums, currencies, permissions, or workflow logic belong in this
package. Every component API is generic; demo data in Storybook and pattern stories is clearly
fictitious.

## Publication

Publication is restricted to the manual GitHub Actions workflow. The workflow requires an exact
`expected_version`, a `publish` confirmation, a clean `main` branch build, passing CI/release
readiness gates, and a version that does not already exist on GitHub Packages. It publishes to
`https://npm.pkg.github.com` with `GITHUB_TOKEN`, then verifies installation of the exact package
version from an isolated consumer project.

## Release Notes

### 0.2.0

- Prepared the next private GitHub Packages release.
- Keeps the public package surface limited to `@agrismartchain/noki-design-system` and
  `@agrismartchain/noki-design-system/styles.css`.
- Preserves the NOKI dashboard themes, Helvetica runtime font stack, responsive layouts,
  FR/EN/AR usage, RTL support, dark mode, and visual regression baseline contract.
